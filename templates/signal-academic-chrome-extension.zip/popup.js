const inputEl = document.getElementById("inputText");
const grabBtn = document.getElementById("grabBtn");
const scanBtn = document.getElementById("scanBtn");
const resultBox = document.getElementById("resultBox");
const riskScoreEl = document.getElementById("riskScore");
const criteriaCountEl = document.getElementById("criteriaCount");
const findingsList = document.getElementById("findingsList");

grabBtn.addEventListener("click", async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => (window.getSelection()?.toString() || document.body?.innerText || "").trim().slice(0, 4000),
    });
    if (result) inputEl.value = result;
  } catch {
    inputEl.placeholder = "Could not read this tab automatically. Paste your rubric text here.";
  }
});

scanBtn.addEventListener("click", () => {
  const raw = (inputEl.value || "").trim();
  if (!raw) return;
  const lines = raw.split(/\n+/).map((l) => l.trim()).filter((l) => l.length > 12).slice(0, 8);
  const traps = [];
  const lower = raw.toLowerCase();
  if (/distinguished|exemplary|critical analysis/.test(lower)) traps.push("Requires explicit synthesis & assumptions for top rubric tier.");
  if (/apa|citation|reference|doi/.test(lower)) traps.push("Verify APA 7th format, DOI links, and 5-year source currency (2021-2026).");
  if (/quantif|metric|benchmark|p-value|regression|cost/.test(lower)) traps.push("Include concrete numeric metrics/benchmarks rather than general claims.");
  if (/theory|model|framework|lewin|kotter|picot|icd-10/.test(lower)) traps.push("Map every stage of the named framework or ICD-10 rationale explicitly.");
  if (traps.length === 0) traps.push("Mirror each rubric prompt as an explicit H2 heading so graders check off every row.");

  const score = Math.min(94, 34 + traps.length * 14 + Math.max(0, lines.length - 2) * 3);
  riskScoreEl.textContent = `${score}% Revision Risk`;
  criteriaCountEl.textContent = `${lines.length || 1} sections`;
  findingsList.innerHTML = "";
  traps.forEach((msg) => {
    const li = document.createElement("li");
    li.textContent = msg;
    findingsList.appendChild(li);
  });
  resultBox.hidden = false;
});
