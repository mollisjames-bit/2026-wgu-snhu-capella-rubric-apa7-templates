const inputEl = document.getElementById("inputText");
const grabBtn = document.getElementById("grabBtn");
const scanBtn = document.getElementById("scanBtn");
const tabRubric = document.getElementById("tabRubric");
const tabApa = document.getElementById("tabApa");
const fullToolLink = document.getElementById("fullToolLink");
const resultBox = document.getElementById("resultBox");
const scoreBadge = document.getElementById("scoreBadge");
const metaBadge = document.getElementById("metaBadge");
const findingsList = document.getElementById("findingsList");

let mode = "rubric";

tabRubric.addEventListener("click", () => {
  mode = "rubric";
  tabRubric.classList.add("is-active");
  tabApa.classList.remove("is-active");
  fullToolLink.href = "https://signalacademic.com/tools/rubric-checker?utm_source=chrome_ext";
  inputEl.placeholder = "Paste your assignment rubric criteria or click Grab Page Text...";
});

tabApa.addEventListener("click", () => {
  mode = "apa";
  tabApa.classList.add("is-active");
  tabRubric.classList.remove("is-active");
  fullToolLink.href = "https://signalacademic.com/tools/apa-checker?utm_source=chrome_ext";
  inputEl.placeholder = "Paste a draft paragraph to check APA 7th citations, passive voice, and tone...";
});

grabBtn.addEventListener("click", async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => (window.getSelection()?.toString() || document.body?.innerText || "").trim().slice(0, 5000),
    });
    if (result) inputEl.value = result;
  } catch {
    inputEl.placeholder = "Paste your rubric or draft text directly here.";
  }
});

scanBtn.addEventListener("click", () => {
  const raw = (inputEl.value || "").trim();
  if (!raw) return;
  findingsList.innerHTML = "";

  if (mode === "rubric") {
    const lines = raw.split(/\n+/).map((l) => l.trim()).filter((l) => l.length > 14).slice(0, 6);
    const items = [];
    lines.forEach((line, idx) => {
      const lower = line.toLowerCase();
      let verb = "Address clearly";
      if (lower.includes("synthesize")) verb = "Synthesize (compare 2+ studies)";
      else if (lower.includes("evaluate")) verb = "Evaluate (weigh pros, cons & metrics)";
      else if (lower.includes("analyze")) verb = "Analyze (break down cause & effect)";
      else if (lower.includes("apply")) verb = "Apply (map named framework)";
      const label = line.replace(/^([A-Z]\d?\.|\d+\.|Criterion\s*\d+:?|-)+\s*/i, "").slice(0, 48);
      items.push(`${idx + 1}. "${label}..." -> ${verb}`);
    });
    if (/distinguished|5 years|2021|doi|apa|metric|icd-10/.test(raw.toLowerCase())) {
      items.push("Tip: Verify 2021-2026 peer-reviewed DOI sources and measurable metrics.");
    }
    if (!items.length) items.push("Tip: Mirror every rubric prompt as an explicit H2 heading.");
    scoreBadge.textContent = `${lines.length || 1} Rubric Sections Mapped`;
    metaBadge.textContent = "Outline Ready";
    items.forEach((txt) => {
      const li = document.createElement("li");
      li.textContent = txt;
      findingsList.appendChild(li);
    });
  } else {
    const words = raw.split(/\s+/).filter(Boolean);
    const passive = (raw.match(/\b(?:is|are|was|were|been|being)\s+[a-z]+ed\b/gi) || []).length;
    const firstPerson = (raw.match(/\b(?:I think|I believe|I feel|in my opinion)\b/gi) || []).length;
    const casual = (raw.match(/\b(?:a lot of|kind of|sort of|basically|obviously|huge|stuff|things)\b/gi) || []).length;
    const cites = (raw.match(/\([A-Z][A-Za-z\s\-]+,\s*(?:19|20)\d{2}|\b[A-Z][a-z]+\s*\((?:19|20)\d{2}\)/g) || []).length;
    const ampersandErr = (raw.match(/\([A-Z][a-z]+\s+and\s+[A-Z][a-z]+,\s*(?:19|20)\d{2}\)/g) || []).length;

    const score = Math.max(40, Math.min(100, 92 - passive * 3 - firstPerson * 8 - casual * 6 - ampersandErr * 7 + (cites > 0 ? 5 : -10)));
    scoreBadge.textContent = `APA & Tone Score: ${score}/100`;
    metaBadge.textContent = `${words.length} words`;

    const findings = [
      `Citations detected: ${cites} (${cites === 0 ? "add APA 7th in-text citations" : "good evidence density"}).`,
      `Passive voice flags: ${passive} | Informal/1st-person flags: ${casual + firstPerson}.`,
    ];
    if (ampersandErr > 0) findings.push(`APA 7th fix: Use "&" instead of "and" inside ${ampersandErr} parenthetical citation(s).`);
    findings.forEach((txt) => {
      const li = document.createElement("li");
      li.textContent = txt;
      findingsList.appendChild(li);
    });
  }
  resultBox.hidden = false;
});
