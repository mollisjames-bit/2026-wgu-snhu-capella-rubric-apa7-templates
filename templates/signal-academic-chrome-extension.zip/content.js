(() => {
  if (window.__signalAcademicInjected) return;
  window.__signalAcademicInjected = true;

  const text = (document.body?.innerText || "").toLowerCase();
  if (!/rubric|assignment|assessment|competency|grading criteria/.test(text)) return;

  chrome.storage.local.get(["saPillDismissed"], (res) => {
    if (res?.saPillDismissed) return;

    const pill = document.createElement("div");
    pill.id = "signal-academic-lms-pill";
    pill.style.cssText = [
      "position:fixed",
      "right:16px",
      "bottom:16px",
      "z-index:2147483640",
      "background:#ffffff",
      "color:#0f172a",
      "font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif",
      "font-size:12.5px",
      "border-radius:12px",
      "padding:8px 12px",
      "box-shadow:0 8px 24px rgba(15,23,42,0.14)",
      "border:1px solid #cbd5e1",
      "display:flex",
      "align-items:center",
      "gap:8px"
    ].join(";");

    const dot = document.createElement("span");
    dot.style.cssText = "width:8px;height:8px;border-radius:999px;background:#10b981;display:inline-block;flex-shrink:0;";

    const label = document.createElement("span");
    label.textContent = "Rubric detected";
    label.style.fontWeight = "600";

    const btn = document.createElement("a");
    btn.textContent = "Pre-check APA & Rubric";
    btn.href = "https://signalacademic.com/tools/rubric-checker?utm_source=chrome_ext_lms&utm_medium=extension";
    btn.target = "_blank";
    btn.rel = "noreferrer";
    btn.style.cssText = "background:#0f172a;color:#ffffff;padding:4px 9px;border-radius:7px;font-weight:600;text-decoration:none;font-size:11.5px;";

    const close = document.createElement("button");
    close.type = "button";
    close.textContent = "×";
    close.title = "Dismiss";
    close.setAttribute("aria-label", "Dismiss");
    close.style.cssText = "background:transparent;border:none;color:#64748b;font-size:15px;cursor:pointer;padding:0 2px;line-height:1;";
    close.addEventListener("click", () => {
      chrome.storage.local.set({ saPillDismissed: true });
      pill.remove();
    });

    pill.append(dot, label, btn, close);
    document.body.appendChild(pill);
  });
})();
