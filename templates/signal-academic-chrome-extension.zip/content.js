(() => {
  if (window.__signalAcademicInjected) return;
  window.__signalAcademicInjected = true;

  const text = (document.body?.innerText || "").toLowerCase();
  const isRelevant = /rubric|assignment|assessment|submission|competency|syllabus|discussion|apa\b/.test(text);
  if (!isRelevant) return;

  const pill = document.createElement("div");
  pill.id = "signal-academic-lms-pill";
  pill.style.cssText = [
    "position:fixed",
    "right:18px",
    "bottom:18px",
    "z-index:2147483640",
    "background:#0f172a",
    "color:#f8fafc",
    "font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif",
    "font-size:13px",
    "border-radius:14px",
    "padding:10px 14px",
    "box-shadow:0 12px 32px rgba(15,23,42,0.35)",
    "border:1px solid rgba(52,211,153,0.45)",
    "display:flex",
    "align-items:center",
    "gap:10px"
  ].join(";");

  const label = document.createElement("span");
  label.textContent = "Check rubric traps before submitting";
  label.style.fontWeight = "600";

  const btn = document.createElement("a");
  btn.textContent = "Free Scan";
  btn.href = "https://signalacademic.com/tools/rubric-checker?utm_source=chrome_ext_lms&utm_medium=extension";
  btn.target = "_blank";
  btn.rel = "noreferrer";
  btn.style.cssText = "background:#10b981;color:#022c22;padding:5px 10px;border-radius:8px;font-weight:800;text-decoration:none;font-size:12px;";

  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "×";
  close.setAttribute("aria-label", "Hide");
  close.style.cssText = "background:transparent;border:none;color:#94a3b8;font-size:16px;cursor:pointer;padding:0 2px;line-height:1;";
  close.addEventListener("click", () => pill.remove());

  pill.append(label, btn, close);
  document.body.appendChild(pill);
})();
